#include "juego.h"
using namespace std;

int main() {
    Juego j;
	j.iniciar();
	return 0;
}
